﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vizsga2
{
    class Szam
    {
        public int szam;
        public int db;

        public Szam(int szam, int db)
        {
            this.szam = szam;
            this.db = db;
        }
    }
}